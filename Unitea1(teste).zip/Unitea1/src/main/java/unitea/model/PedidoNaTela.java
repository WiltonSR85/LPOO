package unitea.model;

public class PedidoNaTela {

	private String nomeAluno;
	private String nomeFamiliar;
	private String nomeMonitor;
	private String informacoes;
	private String turma;
	private String diagnosticoTEA;
	private String disciplina;
	private int idPedido;
	
	public PedidoNaTela() {
		
	}
	
	public PedidoNaTela(String nomeAluno, String nomeFamiliar, String informacoes, String turma, String diagnosticoTEA, String disciplina, int idPedido) {
		
		this.nomeAluno= nomeAluno;
		this.nomeFamiliar= nomeFamiliar;
		this.informacoes= informacoes;
		this.turma= turma;
		this.diagnosticoTEA= diagnosticoTEA;
		this.disciplina= disciplina;
		this.idPedido= idPedido;
	}
	
	public PedidoNaTela(String nomeAluno, String nomeFamiliar, String nomeMonitor, String informacoes, String turma, String diagnosticoTEA,String disciplina, int idPedido) {
		
		this.nomeAluno= nomeAluno;
		this.nomeFamiliar= nomeFamiliar;
		this.nomeMonitor= nomeMonitor;
		this.informacoes= informacoes;
		this.turma= turma;
		this.diagnosticoTEA= diagnosticoTEA;
		this.disciplina= disciplina;
		this.idPedido= idPedido;
	}

	public String getNomeAluno() {
		return nomeAluno;
	}

	public void setNomeAluno(String nomeAluno) {
		this.nomeAluno = nomeAluno;
	}

	public String getNomeFamiliar() {
		return nomeFamiliar;
	}

	public void setNomeFamiliar(String nomeFamiliar) {
		this.nomeFamiliar = nomeFamiliar;
	}

	public String getNomeMonitor() {
		return nomeMonitor;
	}

	public void setNomeMonitor(String nomeMonitor) {
		this.nomeMonitor = nomeMonitor;
	}

	public String getInformacoes() {
		return informacoes;
	}

	public void setInformacoes(String informacoes) {
		this.informacoes = informacoes;
	}

	public String getTurma() {
		return turma;
	}

	public void setTurma(String turma) {
		this.turma = turma;
	}

	public String getDiagnosticoTEA() {
		return diagnosticoTEA;
	}

	public void setDiagnosticoTEA(String diagnosticoTEA) {
		this.diagnosticoTEA = diagnosticoTEA;
	}
	

	public String getDisciplina() {
		return disciplina;
	}

	public void setDisciplina(String disciplina) {
		this.disciplina = disciplina;
	}

	public int getIdPedido() {
		return idPedido;
	}

	public void setIdPedido(int idPedido) {
		this.idPedido = idPedido;
	}
	
	
}
