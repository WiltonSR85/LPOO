package unitea.model;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;

public class MonitorModel extends UsuarioModel{

	private int idMonitor;
	private int anosExperiencia;
	private String formacaoAcademica;
	private String especializacao;
	private List<AlunoModel> alunos;
	private List<String> disciplinas;
	private List<PedidoMonitoriaModel> pedidosMonitoria;
	
	public MonitorModel() {
		
	}

	public MonitorModel(int idUsuario, String nome, String email, String senha, String endereco, String perfil, 
			int idMonitor, int anosExperiencia, String formacaoAcademica, String especializacao) {
		super(idUsuario, nome, email, senha, endereco, perfil);
		this.idMonitor= idMonitor;
		this.anosExperiencia = anosExperiencia;
		this.formacaoAcademica = formacaoAcademica;
		this.especializacao = especializacao;
		this.alunos = new ArrayList<>();
		this.disciplinas = new ArrayList<>();
		this.pedidosMonitoria = new ArrayList<>();
	}
	
	public MonitorModel(int anosExperiencia, String formacaoAcademica, String especializacao, List<String> disciplinas) {
		this.anosExperiencia = anosExperiencia;
		this.formacaoAcademica = formacaoAcademica;
		this.especializacao = especializacao;
		this.alunos = new ArrayList<>();
		this.disciplinas = disciplinas;
	}
	
	

	public int getIdMonitor() {
		return idMonitor;
	}

	public void setIdMonitor(int idMonitor) {
		this.idMonitor = idMonitor;
	}

	public int getAnosExperiencia() {
		return anosExperiencia;
	}

	public void setAnosExperiencia(int anosExperiencia) {
		this.anosExperiencia = anosExperiencia;
	}

	public String getFormacaoAcademica() {
		return formacaoAcademica;
	}

	public void setFormacaoAcademica(String formacaoAcademica) {
		this.formacaoAcademica = formacaoAcademica;
	}

	public String getEspecializacao() {
		return especializacao;
	}

	public void setEspecializacao(String especializacao) {
		this.especializacao = especializacao;
	}

	public List<AlunoModel> getAlunos() {
		return alunos;
	}

	public void setAlunos(List<AlunoModel> alunos) {
		this.alunos = alunos;
	}

	public List<String> getDisciplinas() {
		return disciplinas;
	}

	public void setDisciplinas(List<String> disciplinas) {
		this.disciplinas = disciplinas;
	}

	public List<PedidoMonitoriaModel> getPedidosMonitoria() {
		return pedidosMonitoria;
	}

	public void setPedidosMonitoria(List<PedidoMonitoriaModel> pedidosMonitoria) {
		this.pedidosMonitoria = pedidosMonitoria;
	}
	
	public String getDisciplinasAsJson() {
	    JSONArray jsonArray = new JSONArray(this.disciplinas);
	    return jsonArray.toString();
	}
	
	public void setDisciplinasFromJson(String json) {
	    JSONArray jsonArray = new JSONArray(json);
	    this.disciplinas = new ArrayList<>();
	    for (int i = 0; i < jsonArray.length(); i++) {
	        this.disciplinas.add(jsonArray.getString(i));
	    }
	}
	
	public void exibirDisciplinas() {
		System.out.println("As disciplinas são");
		for(String disciplina : disciplinas) {
			System.out.println(disciplina);
		}
	}
}
