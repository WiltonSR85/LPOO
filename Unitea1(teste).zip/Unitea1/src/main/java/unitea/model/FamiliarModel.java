package unitea.model;

import java.util.ArrayList;
import java.util.List;

public class FamiliarModel extends UsuarioModel{
	
	private int idFamiliar;
	private List<AlunoModel> alunos;
	private List<PedidoMonitoriaModel> pedidosCriados;
	private List<PedidoMonitoriaModel> pedidosAndamento;
	

	public FamiliarModel(int idUsuario, String nome, String email, String senha, String endereco, String perfil, int idFamiliar) {
		super(idUsuario, nome, email, senha, endereco, perfil);
		this.idFamiliar= idFamiliar;
		this.alunos = new ArrayList<>();
		this.pedidosCriados = new ArrayList<>();
		this.pedidosAndamento = new ArrayList<>();
	}

	public FamiliarModel() {
		
	}
	public int getIdFamiliar() {
		return idFamiliar;
	}


	public void setIdFamiliar(int idFamiliar) {
		this.idFamiliar = idFamiliar;
	}


	public List<AlunoModel> getAlunos() {
		return alunos;
	}


	public void setAlunos(List<AlunoModel> alunos) {
		this.alunos = alunos;
	}


	public List<PedidoMonitoriaModel> getPedidosCriados() {
		return pedidosCriados;
	}


	public void setPedidosCriados(List<PedidoMonitoriaModel> pedidosCriados) {
		this.pedidosCriados = pedidosCriados;
	}


	public List<PedidoMonitoriaModel> getPedidosAndamento() {
		return pedidosAndamento;
	}


	public void setPedidosAndamento(List<PedidoMonitoriaModel> pedidosAndamento) {
		this.pedidosAndamento = pedidosAndamento;
	}

	
	
	
}
