package unitea.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import unitea.model.PedidoNaTela;

public class MostrarPedidosCriadosFamiliarDao {

	public List<PedidoNaTela> listarPedidos(int idFamiliar){
		List<PedidoNaTela> pedidos= new ArrayList<>();
		PreparedStatement stmt= null;
		ResultSet rs= null;
		Connection conn = null;
		
		String sql= "SELECT "
		        + "    u.nome AS nome_familiar, "
		        + "    pc.id_pedido AS id_pedido, "
		        + "    pc.informacoes AS informacoes_adicionais, "
		        + "    a.nome AS nome_aluno, "
		        + "    a.turma AS turma, "
		        + "    a.diagnosticoTEA AS diagnostico_tea, "
		        + "    pc.disciplina AS disciplina "
		        + "FROM "
		        + "    familiar f "
		        + "JOIN "
		        + "    usuario u ON f.id_usuario = u.id_usuario "
		        + "JOIN "
		        + "    pedidos_criados pc ON f.id_familiar = pc.id_familiar "
		        + "JOIN "
		        + "    aluno a ON f.id_familiar = a.id_familiar "
		        + "WHERE "
		        + "    f.id_familiar = ?";

		
		try {
			conn = new MysqlConnection().getConnection();
			
			if(conn != null) {
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, idFamiliar);
				
				rs= stmt.executeQuery();
				
				while(rs.next()) {
					String nomeFamiliar= rs.getString("nome_familiar");
					String nomeAluno= rs.getString("nome_aluno");
					String informacoes= rs.getString("informacoes_adicionais");
					String diagnostico= rs.getString("diagnostico_tea");
					String turma= rs.getString("turma");
					String disciplina= rs.getString("disciplina");
					int idPedido= rs.getInt("id_pedido");
					
					System.out.println("AQUI ESTAMOS NOS");
					
					PedidoNaTela pedido= new PedidoNaTela(nomeAluno, nomeFamiliar, informacoes, turma,diagnostico, disciplina, idPedido);
					
					pedidos.add(pedido);
				}
				
				for (PedidoNaTela pedido : pedidos) {
					System.out.println(pedido.getDiagnosticoTEA());
				}
			}else {
				System.out.println("Falha na conexão com o banco de dados.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return pedidos;
	}
}
