package unitea.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import unitea.model.ChatModel;
import unitea.model.PedidoMonitoriaModel;

public class CriarChatDao {

	public PedidoMonitoriaModel CriandoChat(ChatModel chat){
		PedidoMonitoriaModel pedido= new PedidoMonitoriaModel();
		PreparedStatement stmt= null;
		//ResultSet rs= null;
		Connection conn = null;
		
		String sql= "INSERT INTO UNITEA.chat (id_familiar, id_monitor, id_pedido, nome_chat) VALUES (?, ?, ?, ?)";

		
		try {
			conn = new MysqlConnection().getConnection();
			
			if(conn != null) {
				stmt = conn.prepareStatement(sql);
				stmt.setInt(1, chat.getIdFamiliar());
				stmt.setInt(2, chat.getIdMonitor());
				stmt.setInt(3, chat.getIdPedidoMonitoriaAssociado());
				stmt.setString(4, chat.getNomeChat());
				
				System.out.println("Pelo menos a conexão ta acontecendo");
				System.out.println(chat.getIdFamiliar());
				System.out.println(chat.getIdMonitor());
				System.out.println(chat.getIdPedidoMonitoriaAssociado());
				System.out.println(chat.getNomeChat());
				
				int rowsAffected = stmt.executeUpdate();
				
				if(rowsAffected > 0) {
					System.out.println("estamos aqui");
					
					pedido= new PedidoMonitoriaModel(chat);
					
				}
				
			}else {
				System.out.println("Falha na conexão com o banco de dados.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
            try {
                //if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
		
		return pedido;
	}
}
