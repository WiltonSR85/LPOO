
package unitea.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import unitea.dao.MysqlConnection;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Servlet implementation class Login
 */
//@WebServlet("/Login")
public class Login3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		// Captura os dados de login
        String email = request.getParameter("Email");
        String senha = request.getParameter("Senha");

        // Variáveis para armazenar os dados do usuário
        int idUsuario= 0;
        String nome = null;
        String email1= null;
        String senha1= null;
        String endereco= null;
        String perfil = null;
        int idFamiliar= 0;
        int idAluno= 0;
        String nomeAluno= null;
        String turma= null;
        String diagnostico= null;
        int idMentor=0;
        String especializacao= null;
        String anosExperiencia=null;
        String formacaoAcademica=null;
        Connection conn = null;


        try {
            
        	conn = new MysqlConnection().getConnection();
            String query = "SELECT id_usuario, nome, email, senha, endereco, perfil FROM usuario WHERE email = ? AND senha = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, email);
            stmt.setString(2, senha);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
            	idUsuario= rs.getInt("id_usuario");
                nome = rs.getString("nome");
                email1= rs.getString("email");
                senha1= rs.getString("senha");
                endereco= rs.getString("endereco");
                perfil = rs.getString("perfil");

                HttpSession session = request.getSession();
                session.setAttribute("id_usuario", idUsuario);
                session.setAttribute("nome", nome);
                session.setAttribute("email", email1);
                session.setAttribute("senha", senha1);
                session.setAttribute("endereco", endereco);
                session.setAttribute("perfil", perfil);

                if ("familiar".equalsIgnoreCase(perfil)) {
                	
                	String query3 = "SELECT id_usuario, nome, email, senha, endereco, perfil FROM usuario WHERE email = ? AND senha = ?";
                    PreparedStatement stmt3 = conn.prepareStatement(query3);
                    stmt3.setString(1, email);
                    stmt3.setString(2, senha);

                    ResultSet rs3 = stmt3.executeQuery();

                    if (rs3.next()) {
                    	idUsuario= rs3.getInt("id_usuario");
                        nome = rs3.getString("nome");
                        email1= rs3.getString("email");
                        senha1= rs3.getString("senha");
                        endereco= rs3.getString("endereco");
                        perfil = rs3.getString("perfil");

                        session.setAttribute("id_usuarioFamiliar", idUsuario);
                        session.setAttribute("nomeFamiliar", nome);
                        session.setAttribute("emailFamiliar", email1);
                        session.setAttribute("senhaFamiliar", senha1);
                        session.setAttribute("enderecoFamiliar", endereco);
                        session.setAttribute("perfilFamiliar", perfil);
                    }
                    String query1 = "SELECT id_familiar FROM familiar WHERE id_usuario = ?";
                    PreparedStatement stmt1 = conn.prepareStatement(query1);
                    stmt1.setInt(1, idUsuario); 
                    ResultSet rs1 = stmt1.executeQuery();

                    if (rs1.next()) {
                        idFamiliar = rs1.getInt("id_familiar");
                    }
                    String query2 = "SELECT id_aluno, nome, diagnosticoTEA, turma FROM UNITEA.aluno WHERE id_familiar = ?";
                    PreparedStatement stmt2 = conn.prepareStatement(query2);
                    stmt2.setInt(1, idFamiliar); 
                    ResultSet rs2 = stmt2.executeQuery();
                    
                    if (rs2.next()) {
                    	idAluno= rs2.getInt("id_aluno");
                        nomeAluno = rs2.getString("nome");
                        turma= rs2.getString("turma");
                        diagnostico= rs2.getString("diagnosticoTEA");
                    }
                    
                    session.setAttribute("id_familiar", idFamiliar);
                    session.setAttribute("id_aluno", idAluno);
                    session.setAttribute("nomeAluno", nomeAluno);
                    session.setAttribute("turma", turma);
                    session.setAttribute("diagnostico", diagnostico);

                    response.sendRedirect("telaFamiliar.jsp"); 
                } else if ("mentor".equalsIgnoreCase(perfil)) {
                	String query3 = "SELECT id_usuario, nome, email, senha, endereco, perfil FROM usuario WHERE email = ? AND senha = ?";
                    PreparedStatement stmt3 = conn.prepareStatement(query3);
                    stmt3.setString(1, email);
                    stmt3.setString(2, senha);

                    ResultSet rs3 = stmt3.executeQuery();

                    if (rs3.next()) {
                    	idUsuario= rs3.getInt("id_usuario");
                        nome = rs3.getString("nome");
                        email1= rs3.getString("email");
                        senha1= rs3.getString("senha");
                        endereco= rs3.getString("endereco");
                        perfil = rs3.getString("perfil");

                        session.setAttribute("id_usuarioMonitor", idUsuario);
                        session.setAttribute("nomeMonitor", nome);
                        session.setAttribute("emailMonitor", email1);
                        session.setAttribute("senhaMonitor", senha1);
                        session.setAttribute("enderecoMonitor", endereco);
                        session.setAttribute("perfilMonitor", perfil);
                    }
                	String query2 = "SELECT id_monitor, especializacao, anosExperiencia, formacaoAcademica, disciplinas FROM monitor WHERE id_usuario = ?";
                    PreparedStatement stmt2 = conn.prepareStatement(query2);
                    stmt2.setInt(1, idUsuario); 
                    ResultSet rs2 = stmt2.executeQuery();
                    
                    if (rs2.next()) {
                        idMentor = rs2.getInt("id_monitor");
                        especializacao = rs2.getString("especializacao");
                        anosExperiencia = rs2.getString("anosExperiencia");
                        formacaoAcademica = rs2.getString("formacaoAcademica");

                        String disciplinasJson = rs2.getString("disciplinas");
                        if (disciplinasJson != null && !disciplinasJson.isEmpty()) {
                            try {
                                org.json.JSONArray jsonArray = new org.json.JSONArray(disciplinasJson);
                                List<String> disciplinas = new ArrayList<>();

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    disciplinas.add(jsonArray.getString(i)); 
                                }
                                session.setAttribute("disciplinas", disciplinas);

                            } catch (Exception e) {
                                e.printStackTrace(); 
                            }
                        }
                    }
                    
                    session.setAttribute("id_mentor", idMentor);
                    session.setAttribute("especializacao", especializacao);
                    session.setAttribute("anosExperiencia", anosExperiencia);
                    session.setAttribute("formacaoAcademica", formacaoAcademica);
                    
                    response.sendRedirect("telaMentor.jsp"); 
                }


            } else {
                request.setAttribute("mensagem", "Email ou senha incorretos.");
                RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
                dispatcher.forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("mensagem", "Erro ao acessar o banco de dados.");
            RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
            dispatcher.forward(request, response);
        }
    }

}
